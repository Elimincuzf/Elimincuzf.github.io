# LoveWall

#### 自我介绍
LoveWall，顾名思义，其实就是表白墙。
一生那么长，只为遇见你。
#### 特色功能
1. 点赞
2. 发评论
3. 发弹幕
4. 多校区
5. 分享页
6. 涉证、涉H、暴力、违禁物等名词进行检测
7. wait Update。
#### 官方信息
1.官方演示地址：http://lw2.demo.kres.cn
2.官方BUG提交反馈：https://pro.kres.cn/form/index/bugsubmit
3.官方邮箱反馈地址：admin@jishuzy.com
4.官方完整更新下载地址：https://gitee.com/ncnet/10001
5.官方增量更新下载地址：https://www.521wall.cn
此版本将会不断更新！
#### 软件架构
1.前端框架：LayUI 2.4、Jquery
2.后端框架：ThinkPHP 5.0.24
3.图标素材：阿里巴巴
4.API调用：天气网、Ncnet官方
#### 测试环境
1.PHP     ：7.2.11
2.Mysql   : 5.7
3.Apache  ：2.4.35
#### 安装教程

1. 下载完整源码
2. 上传源码到服务器并设置运行目录为 /public
3. 使用伪静态规则ThinkPHP（此处不提供）
4. 导入根目录下的 love.sql 文件，并配置application/database.php文件下的连接信息
5. 配置发信邮箱信息，编辑 extend\PHPMailer\SendEmail.php 文件，否则无法对提交的校区进行审核！
6. 大功告成，开始尽情使用吧！
#### 使用说明
1. 尽情发挥
2. 尽情发挥
3. 尽情发挥
#### 参与贡献
1. Csdn 社区、手册 (滑稽.jpg)
2. 文案：猫腻
3. 开发：橘子(Cheng)、Ncnet
4. 测试：猫腻、久念
#### 码云特技

1. 使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2. 码云官方博客 [blog.gitee.com](https://blog.gitee.com)
3. 你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解码云上的优秀开源项目
4. [GVP](https://gitee.com/gvp) 全称是码云最有价值开源项目，是码云综合评定出的优秀开源项目
5. 码云官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6. 码云封面人物是一档用来展示码云会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)