-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2019-05-25 01:49:27
-- 服务器版本： 5.7.24
-- PHP 版本： 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `love`
--

-- --------------------------------------------------------

--
-- 表的结构 `love_barrager`
--

CREATE TABLE `love_barrager` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `info` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `love_barrager`
--

INSERT INTO `love_barrager` (`id`, `post_id`, `info`, `img`, `color`) VALUES
(7, 219, '1697779290', 'https://q.qlogo.cn/headimg_dl?dst_uin=1697779290&spec=100', '#7faf11'),
(8, 219, '233333', 'https://q.qlogo.cn/headimg_dl?dst_uin=43593542&spec=100', '#0fe3f3'),
(9, 218, '23333', 'https://q.qlogo.cn/headimg_dl?dst_uin=1697779290&spec=100', '#529bd2'),
(10, 187, '3333', 'https://q.qlogo.cn/headimg_dl?dst_uin=43593542&spec=100', '#f51c1c'),
(11, 227, '搞事情', 'https://q.qlogo.cn/headimg_dl?dst_uin=1697779290&spec=100', ''),
(12, 230, '搞事', 'https://q.qlogo.cn/headimg_dl?dst_uin=1697779290&spec=100', ''),
(13, 231, '？？？？？？？？？？？？？？？？？', 'https://q.qlogo.cn/headimg_dl?dst_uin=1697779290&spec=100', ''),
(14, 253, 'cnm', 'https://q.qlogo.cn/headimg_dl?dst_uin=1697779290&spec=100', ''),
(15, 253, '<script', 'https://q.qlogo.cn/headimg_dl?dst_uin=1697779290&spec=100', ''),
(16, 253, 'alert(\'2333\')', 'https://q.qlogo.cn/headimg_dl?dst_uin=1697779290&spec=100', '');

-- --------------------------------------------------------

--
-- 表的结构 `love_comment`
--

CREATE TABLE `love_comment` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '上级评论id,若是一级评论则为0',
  `nickname` varchar(100) DEFAULT NULL COMMENT '评论人昵称',
  `head_pic` varchar(400) DEFAULT NULL COMMENT '评论人头像',
  `content` text COMMENT '评论内容',
  `create_time` datetime DEFAULT NULL COMMENT '评论或回复发表时间',
  `post_id` int(11) DEFAULT NULL,
  `like` int(255) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `love_contents`
--

CREATE TABLE `love_contents` (
  `id` int(255) NOT NULL,
  `zid` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `sex` varchar(1) NOT NULL,
  `qq` text NOT NULL,
  `ip` text NOT NULL,
  `mous` varchar(2) NOT NULL DEFAULT '0',
  `name` varchar(11) NOT NULL,
  `date` int(255) NOT NULL,
  `like` int(255) DEFAULT '0',
  `comm` int(255) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `love_notice`
--

CREATE TABLE `love_notice` (
  `id` int(11) NOT NULL,
  `tid` varchar(255) DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `love_notice`
--

INSERT INTO `love_notice` (`id`, `tid`, `content`, `time`) VALUES
(3, '10003', '新公告：<br>禁止发布涉证言论', 1557644439);

-- --------------------------------------------------------

--
-- 表的结构 `love_open_school`
--

CREATE TABLE `love_open_school` (
  `id` int(11) NOT NULL,
  `ip` text NOT NULL,
  `web_name` varchar(20) DEFAULT NULL,
  `email` varchar(29) DEFAULT NULL,
  `reason` text,
  `logo_img` text,
  `addtime` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `love_options`
--

CREATE TABLE `love_options` (
  `id` int(255) NOT NULL,
  `name` text,
  `value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `love_options`
--

INSERT INTO `love_options` (`id`, `name`, `value`) VALUES
(1, 'title', '2332'),
(2, 'keywords', 'jishuzy'),
(3, 'description', '我说的话，不知远方的人听见了吗？'),
(4, 'icp', '桂ICP备1900468号'),
(6, 'limit_time', '2'),
(7, 'limit_mous', '0'),
(8, 'qq', '43593542'),
(10, 'name', '表白墙V2.0'),
(11, 'page_about', '学校：北部湾大学<br>站点:lovewall.test'),
(12, 'limit_ip', '4'),
(13, 'admin_account', '1');

-- --------------------------------------------------------

--
-- 表的结构 `love_user`
--

CREATE TABLE `love_user` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `openid` text,
  `qq` int(10) NOT NULL,
  `isadmin` int(11) DEFAULT '0',
  `login_time` datetime DEFAULT NULL,
  `login_ip` text,
  `pass_err` int(255) UNSIGNED ZEROFILL DEFAULT '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
  `email` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `love_user`
--

INSERT INTO `love_user` (`id`, `username`, `password`, `openid`, `qq`, `isadmin`, `login_time`, `login_ip`, `pass_err`, `email`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '', 1697779290, 1, '2019-02-03 22:34:51', '127.0.0.1', 000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000, 'admin@jishuzy.com');

-- --------------------------------------------------------

--
-- 表的结构 `love_user_log`
--

CREATE TABLE `love_user_log` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `client_ip` varchar(255) NOT NULL,
  `exec_time` datetime NOT NULL,
  `exec_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `love_user_log`
--

INSERT INTO `love_user_log` (`id`, `uid`, `client_ip`, `exec_time`, `exec_name`) VALUES
(116, 1, '36.23.31.45', '2019-04-08 10:40:26', '登陆系统'),
(117, 1, '171.10.170.128', '2019-04-15 19:00:49', '登陆系统'),
(118, 1, '171.10.170.128', '2019-04-15 19:00:54', '登陆系统');

-- --------------------------------------------------------

--
-- 表的结构 `love_website`
--

CREATE TABLE `love_website` (
  `id` int(11) UNSIGNED NOT NULL,
  `zid` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '冻结=0，正常=1；',
  `count` int(11) NOT NULL DEFAULT '0',
  `web_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `web_qq` varchar(255) DEFAULT NULL,
  `web_description` text CHARACTER SET utf8,
  `web_logo` text,
  `hot` int(11) UNSIGNED ZEROFILL DEFAULT '00000000000'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `love_website`
--

INSERT INTO `love_website` (`id`, `zid`, `status`, `count`, `web_name`, `web_qq`, `web_description`, `web_logo`, `hot`) VALUES
(2, '46f312f8-599f-11e9-90ff-1a23648d9544', 1, 23, '南宁职业技术学院', '1697779290', '23333333333333', 'https://i.loli.net/2019/05/25/5ce8908de1f9d47116.jpg', 00000000035),
(3, '160cd88a-7f48-9fdf-667a-80e363d9f541', 1, 3, 'Jishuzy', '1697779290', '技术资源网', 'http://img01.sogoucdn.com/app/a/100520146/A5D43F0DB34C44E1B4EAB63DFDBCAC25', 00000000006),
(4, 'bfd1b1c3-f35e-1b02-f5df-2444ae9da876', 1, 0, '南宁职业技术学院', '1697779290@qq.com', NULL, 'http://img01.sogoucdn.com/app/a/100520146/0AD7AE4A5B93BD1FA7394B2151273B8A', 00000000002),
(5, '712b19eb-0c61-2370-32ce-b97b2319e6ba', 1, 0, '南职院', 'wy-hai@qq.com', 'Ncvt', 'http://img04.sogoucdn.com/app/a/100520146/0AD7AE4A5B93BD1FA7394B2151273B8A', 00000000002),
(6, '076bde61-d061-344b-2c3f-29d27f2118fe', 1, 0, '南宁职业技术学院', '1697779290@qq.com', NULL, 'http://img01.sogoucdn.com/app/a/100520146/0AD7AE4A5B93BD1FA7394B2151273B8A', 00000000000),
(7, '1fd64792-f2a4-948f-9b2c-e1a49194dedb', 1, 0, '测试', 'admin@jishuzy.com', '123213', 'https://i.loli.net/2019/05/25/5ce88fbf7733664350.jpg', 00000000000);

--
-- 转储表的索引
--

--
-- 表的索引 `love_barrager`
--
ALTER TABLE `love_barrager`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `love_comment`
--
ALTER TABLE `love_comment`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `love_contents`
--
ALTER TABLE `love_contents`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `love_notice`
--
ALTER TABLE `love_notice`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `love_open_school`
--
ALTER TABLE `love_open_school`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `love_options`
--
ALTER TABLE `love_options`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `love_user`
--
ALTER TABLE `love_user`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `love_user_log`
--
ALTER TABLE `love_user_log`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `love_website`
--
ALTER TABLE `love_website`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `love_barrager`
--
ALTER TABLE `love_barrager`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- 使用表AUTO_INCREMENT `love_comment`
--
ALTER TABLE `love_comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id', AUTO_INCREMENT=257;

--
-- 使用表AUTO_INCREMENT `love_contents`
--
ALTER TABLE `love_contents`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;

--
-- 使用表AUTO_INCREMENT `love_notice`
--
ALTER TABLE `love_notice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- 使用表AUTO_INCREMENT `love_open_school`
--
ALTER TABLE `love_open_school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- 使用表AUTO_INCREMENT `love_options`
--
ALTER TABLE `love_options`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- 使用表AUTO_INCREMENT `love_user`
--
ALTER TABLE `love_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- 使用表AUTO_INCREMENT `love_user_log`
--
ALTER TABLE `love_user_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- 使用表AUTO_INCREMENT `love_website`
--
ALTER TABLE `love_website`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
